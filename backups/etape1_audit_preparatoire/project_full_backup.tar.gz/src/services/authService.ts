/**
 * Service d'Authentification Individuelle et de Gestion des Sessions
 * NIGER SÉCURITÉ - Niamey
 *
 * Ce service encapsule Firebase Authentication avec persistance locale sécurisée
 * et réconciliation du profil de rôle stocké dans Firestore.
 */

import {
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User,
  browserLocalPersistence,
  setPersistence,
} from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../firebase';
import { UserProfile, UserSpace } from '../types';

const STORAGE_KEYS_AUTH = {
  CACHED_PROFILE: 'niger_securite_cached_user_profile_v1',
  LAST_LOGIN_TIMESTAMP: 'niger_securite_last_auth_timestamp_v1',
} as const;

/**
 * Traduit les codes d'erreur techniques Firebase Auth en messages clairs en français.
 */
function translateAuthError(errorCode: string): string {
  switch (errorCode) {
    case 'auth/invalid-credential':
    case 'auth/wrong-password':
    case 'auth/user-not-found':
      return 'Identifiant ou mot de passe incorrect. Vérifiez vos informations de connexion.';
    case 'auth/invalid-email':
      return 'Adresse email invalide. Veuillez saisir une adresse électronique correcte.';
    case 'auth/user-disabled':
      return 'Ce compte utilisateur a été désactivé par la Direction. Veuillez contacter votre responsable.';
    case 'auth/too-many-requests':
      return 'Trop de tentatives infructueuses. L’accès est temporairement suspendu par mesure de sécurité. Réessayez dans quelques minutes.';
    case 'auth/network-request-failed':
      return 'Connexion réseau impossible. Une connexion Internet active est nécessaire pour authentifier ce compte pour la première fois.';
    default:
      return 'Une erreur est survenue lors de l’authentification. Veuillez réessayer.';
  }
}

/**
 * Sauvegarde le profil utilisateur dans le stockage local pour le fonctionnement hors ligne.
 */
export function saveCachedUserProfile(profile: UserProfile | null): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    if (profile) {
      window.localStorage.setItem(STORAGE_KEYS_AUTH.CACHED_PROFILE, JSON.stringify(profile));
      window.localStorage.setItem(STORAGE_KEYS_AUTH.LAST_LOGIN_TIMESTAMP, Date.now().toString());
    } else {
      window.localStorage.removeItem(STORAGE_KEYS_AUTH.CACHED_PROFILE);
      window.localStorage.removeItem(STORAGE_KEYS_AUTH.LAST_LOGIN_TIMESTAMP);
    }
  } catch (err) {
    console.warn('[NIGER SÉCURITÉ Auth] Échec de mise en cache locale du profil:', err);
  }
}

/**
 * Récupère le dernier profil utilisateur mis en cache localement.
 */
export function getCachedUserProfile(): UserProfile | null {
  if (typeof window === 'undefined' || !window.localStorage) return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEYS_AUTH.CACHED_PROFILE);
    if (!raw) return null;
    return JSON.parse(raw) as UserProfile;
  } catch {
    return null;
  }
}

/**
 * Récupère le profil d'un utilisateur depuis Firestore avec repli sécurisé sur le cache local.
 */
export async function fetchUserProfile(uid: string): Promise<UserProfile | null> {
  // 1. Si hors connexion, retourner immédiatement le profil en cache
  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    const cached = getCachedUserProfile();
    if (cached && cached.uid === uid) return cached;
  }

  // 2. Requête vers le document Firestore /users/{uid}
  try {
    const userDocRef = doc(db, 'users', uid);
    const snap = await getDoc(userDocRef);

    if (snap.exists()) {
      const data = snap.data();
      const profile: UserProfile = {
        uid,
        email: data.email || auth.currentUser?.email || '',
        nom: data.nom || 'Utilisateur',
        prenom: data.prenom,
        role: (data.role as UserSpace) || 'controleur',
        statut: data.statut === 'desactive' ? 'desactive' : 'actif',
        grade: data.grade,
        telephone: data.telephone,
        sitesAssignesIds: Array.isArray(data.sitesAssignesIds) ? data.sitesAssignesIds : [],
        doitChangerPin: Boolean(data.doitChangerPin),
        derniereConnexion: new Date().toISOString(),
        creeLe: data.creeLe || new Date().toISOString(),
      };

      saveCachedUserProfile(profile);
      return profile;
    }
  } catch (err) {
    console.warn('[NIGER SÉCURITÉ Auth] Échec récupération Firestore /users, utilisation du cache:', err);
  }

  // 3. Repli si document non encore initialisé dans Firestore (première connexion transition)
  const cached = getCachedUserProfile();
  if (cached && cached.uid === uid) return cached;

  // Profil basique par défaut dérivé du compte Auth connecté
  if (auth.currentUser) {
    const email = auth.currentUser.email || '';
    let inferredRole: UserSpace = 'controleur';
    let defaultNom = 'Agent NIGER SÉCURITÉ';

    if (email.toLowerCase().includes('direction') || email.toLowerCase().includes('directeur')) {
      inferredRole = 'direction';
      defaultNom = 'Direction Générale';
    } else if (email.toLowerCase().includes('compta')) {
      inferredRole = 'comptabilite';
      defaultNom = 'Service Comptabilité';
    }

    const fallbackProfile: UserProfile = {
      uid,
      email,
      nom: auth.currentUser.displayName || defaultNom,
      role: inferredRole,
      statut: 'actif',
      derniereConnexion: new Date().toISOString(),
    };
    saveCachedUserProfile(fallbackProfile);
    return fallbackProfile;
  }

  return null;
}

/**
 * Connexion individuelle par adresse email et mot de passe.
 * Configure la persistance locale de la session avant la requête.
 */
export async function loginWithEmail(
  email: string,
  pass: string
): Promise<{ success: boolean; user?: UserProfile; error?: string }> {
  try {
    // 1. Forcer la persistance locale IndexedDB / LocalStorage
    await setPersistence(auth, browserLocalPersistence);

    // 2. Tentative d'authentification individuelle
    const cred = await signInWithEmailAndPassword(auth, email.trim(), pass);
    const uid = cred.user.uid;

    // 3. Chargement du profil certifié et vérification du statut actif
    const profile = await fetchUserProfile(uid);

    if (profile && profile.statut === 'desactive') {
      await firebaseSignOut(auth);
      saveCachedUserProfile(null);
      return {
        success: false,
        error: 'Ce compte utilisateur a été désactivé par la Direction. Accès refusé.',
      };
    }

    return {
      success: true,
      user: profile || undefined,
    };
  } catch (err: any) {
    console.error('[NIGER SÉCURITÉ Auth] Erreur de connexion:', err);
    return {
      success: false,
      error: translateAuthError(err?.code || ''),
    };
  }
}

/**
 * Déconnexion individuelle propre et purge sécurisée de la session locale.
 */
export async function logoutUser(): Promise<void> {
  try {
    await firebaseSignOut(auth);
  } catch (err) {
    console.warn('[NIGER SÉCURITÉ Auth] Erreur lors de signOut:', err);
  } finally {
    saveCachedUserProfile(null);
  }
}

/**
 * Abonnement réactif à l'état d'authentification Firebase.
 * Notifie l'application en temps réel dès qu'un utilisateur se connecte ou se déconnecte.
 */
export function subscribeToAuthState(
  callback: (profile: UserProfile | null, firebaseUser: User | null) => void
): () => void {
  // Synchronisation immédiate avec le profil local pour affichage instantané sans attente réseau
  const initialCached = getCachedUserProfile();
  if (initialCached) {
    callback(initialCached, auth.currentUser);
  }

  return onAuthStateChanged(auth, async (user) => {
    if (user) {
      const profile = await fetchUserProfile(user.uid);
      callback(profile, user);
    } else {
      callback(null, null);
    }
  });
}
